#!/usr/bin/env bash
# ============================================================================
# Accountable Mail Association - content policy check
# Run from the repo root:  ./scripts/check.sh
# Exits non-zero on any violation, so it can gate a commit or a CI build.
# ============================================================================
set -uo pipefail
cd "$(dirname "$0")/.."

FAIL=0
red()  { printf "\033[31m%s\033[0m\n" "$1"; }
grn()  { printf "\033[32m%s\033[0m\n" "$1"; }
head_() { printf "\n\033[1m%s\033[0m\n" "$1"; }

PAGES=$(ls *.html 2>/dev/null | grep -v '^_template')

# ---------------------------------------------------------------------------
head_ "1. Forbidden terms (vendor neutrality)"
# Add any new company, product, partner, or customer name to this list.
FORBIDDEN=(
  "Easy Send" "EasySend" "Digitalized" "Krengeltech" "Krengel"
  "GrayHair" "Gray Hair" "ConnectSuite" "Connect Suite"
  "BlueCrest" "Quadient" "Solimar" "Pitney" "Neopost" "Bell and Howell"
  "SimpleCertifiedMail" "Certified Mail Envelopes" "Walz"
  "Fiserv" "State Farm" "Nordis" "Docufree" "Mortgage Connect" "CMSI"
)
for term in "${FORBIDDEN[@]}"; do
  if grep -ril "$term" --include='*.html' --include='*.css' --include='*.md' . >/dev/null 2>&1; then
    red "  FORBIDDEN TERM: '$term' found in:"
    grep -ril "$term" --include='*.html' --include='*.css' . | grep -v CONTENT-POLICY | grep -v 'scripts/' | sed 's/^/    /'
    FAIL=1
  fi
done
[ $FAIL -eq 0 ] && grn "  clean"

# ---------------------------------------------------------------------------
head_ "2. Non-USPS outbound links"
BADLINKS=$(grep -oh 'href="https\?://[^"]*"' $PAGES 2>/dev/null \
  | sed 's/href="//; s/"$//' \
  | grep -v 'usps.com' \
  | grep -v 'usps.gov' \
  | grep -v 'fonts.googleapis.com' \
  | grep -v 'fonts.gstatic.com' \
  | grep -v 'linkedin.com' \
  | sort -u)
if [ -n "$BADLINKS" ]; then
  red "  Review these outbound links. Only USPS, fonts, and LinkedIn are expected:"
  echo "$BADLINKS" | sed 's/^/    /'
  FAIL=1
else
  grn "  clean"
fi

# ---------------------------------------------------------------------------
head_ "3. Em dashes"
if grep -l '—' *.html assets/*.css 2>/dev/null | grep -q .; then
  red "  Em dashes found in:"
  grep -l '—' *.html assets/*.css 2>/dev/null | sed 's/^/    /'
  FAIL=1
else
  grn "  clean"
fi

# ---------------------------------------------------------------------------
head_ "4. Broken internal links"
python3 - <<'PY'
import re, os, glob, sys
files = {os.path.basename(p) for p in glob.glob('*.html')}
bad = []
for p in glob.glob('*.html'):
    if os.path.basename(p).startswith('_template'):
        continue
    for href in re.findall(r'href="([^"]+)"', open(p).read()):
        if href.startswith(('http', 'mailto:', '#')):
            continue
        target = href.split('#')[0]
        if not target:
            continue
        if target.startswith('assets/'):
            if not os.path.exists(target):
                bad.append((p, href))
        elif target not in files:
            bad.append((p, href))
for p, h in bad:
    print(f"    {p} -> {h}")
sys.exit(1 if bad else 0)
PY
if [ $? -ne 0 ]; then red "  broken links above"; FAIL=1; else grn "  clean"; fi

# ---------------------------------------------------------------------------
head_ "5. Topic pages missing a sources block"
MISSING=""
for f in $PAGES; do
  case "$f" in
    index.html|topics.html|about.html|community.html|glossary.html) continue ;;
  esac
  grep -q 'class="sources"' "$f" || MISSING="$MISSING $f"
done
if [ -n "$MISSING" ]; then
  red "  Missing sources block:"; for f in $MISSING; do echo "    $f"; done; FAIL=1
else
  grn "  clean"
fi

# ---------------------------------------------------------------------------
head_ "6. Pages missing a review date"
MISSING=""
for f in $PAGES; do
  case "$f" in
    index.html|about.html|community.html) continue ;;
  esac
  grep -q 'Reviewed\|Updated' "$f" || MISSING="$MISSING $f"
done
if [ -n "$MISSING" ]; then
  red "  Missing review date:"; for f in $MISSING; do echo "    $f"; done; FAIL=1
else
  grn "  clean"
fi

# ---------------------------------------------------------------------------
head_ "7. Unreplaced template placeholders"
PH=$(grep -l 'PAGE TITLE\|SOURCE-URL\|RELATED-PAGE\|PARENT-PILLAR' $PAGES 2>/dev/null)
if [ -n "$PH" ]; then
  red "  Placeholder text still present in:"; echo "$PH" | sed 's/^/    /'; FAIL=1
else
  grn "  clean"
fi

echo
if [ $FAIL -eq 0 ]; then
  grn "PASS. Safe to commit."
else
  red "FAIL. Fix the items above before committing."
fi
exit $FAIL
